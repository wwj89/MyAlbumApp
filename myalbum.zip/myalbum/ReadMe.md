## Technology stack and status management

### Front-end technology stack

- React 18
- React Router 6
- Vite
- PWA

### Backend technology stack

- Node.js
- Express

### Status management

- Front end: React’s built-in useState and useEffect hooks

## Environment setup and preparation

### Environment configuration

- Execute the command in the project root directory to install dependencies: `npm install`

## Startup project

Run the `pnpm i` command in the terminal to install project dependencies in this directory

`cd webui` command enters the `webui` subdirectory

Run the `pnpm i` command again in the `webui` directory to install dependencies specific to the webui subproject.

The `cd..` command returns to the upper level directory and switches to the cmd terminal by running the `cmd` command.

In the cmd terminal, execute the `mklink /J public\data data` command, which creates a symbolic link named `data` to the `public\data` directory.

Finally run the `npm run start` command to start the project

### Front-end project startup

1. Enter the front-end project root directory
2. Execute the command to start development mode: `npm run start`

### Backend API server startup

1. Enter the backend project root directory
2. Execute the command to start the server: `npm run serve`

##Access project

### Front-end web application

- Visit the address in the browser: http://localhost:3000

## Project structure

```
.
├── public                      // Front-end web application packaging results
│ ├── webui                     // Front-end Web application source code
├── buildScript                 // Generate PWA application service worker script
├── public                      // static resources
│ ├── icon                      // application icon directory
│ ├── manifest.json             // PWA application configuration file
│ ├── logo.svg                  // Apply default icon
├── src                         // Front-end Web application source code directory
│ ├── components                // Front-end component directory
│ ├── pages                     // Front-end page directory
│ ├── config                    // Application configuration and offline function implementation
│ ├── main.jsx                  // React application entry file
│ ├── index.css                 // Apply style file
│ ├── tool.css                  // Tool style file
├── vite.config.js              // Vite configuration file
├── app.js                      // Backend API service program
├── package.json                // project configuration file
├── README.md                   // Project description file
```

## Pages and components

- Page
   - Album page: src\pages\App
   - Add photo page: src\pages\AddPhoto
- components
   - Header component: src\components\Header
   - Bottom navigation component: src\components\Footer
   - Album card component: src\components\Card
   - Layout component: src\components\Layout
   - Photo component: src\components\PhotoTaker

## Progressive Web Apps (PWA) Cache Strategy

This project uses network priority mode. Specific features include:

- When the application is opened for the first time, the application's resources, including JavaScript, CSS, images, etc., will be downloaded and cached locally.
- When you open the app again, it will prioritize network requests and update the cache just like when you open the app for the first time.
- Album data will be copied to localStorage, supporting offline access.
- When offline, the album list API data request response will fail. The client will use localStorage album data, save new and delete requests, update the album data and save it to localStorage.
- When going online, listen for network connected events and trigger resending of locally saved requests.
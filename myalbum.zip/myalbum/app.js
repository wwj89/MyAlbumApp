const express = require('express');
const cors = require('cors');

const fs = require('fs');
const path = require('path');

const PORT = 3000;
const API_HOST = `http://localhost:${PORT}`;
const DATA_DIR = path.join(__dirname, 'data')
const PHOTO_DIR = path.join(__dirname, 'data', 'photo');
const DATA_PATH = path.join(DATA_DIR, 'list.json');


function initDBFile() {
    if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
        fs.writeFileSync(DATA_PATH, '[]');
    }
    if (!fs.existsSync(PHOTO_DIR)) {
        fs.mkdirSync(PHOTO_DIR, { recursive: true });
    }
}

initDBFile();
const app = express();

app.use(cors());


app.use(express.json({ limit: '20mb' }));

app.use(express.urlencoded({ extended: true }));



app.use(express.static(path.join(__dirname, 'public')));


function readAlbums() {
    try {
        const data = fs.readFileSync(DATA_PATH, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return [];
    }
}


function writeAlbums(albums) {
    fs.writeFileSync(DATA_PATH, JSON.stringify(albums, null, 2));
}

function savePhoto(base64Image) {
    
    const matches = base64Image.match(/^(data:image\/.*;base64,)(.*)$/);
    if (!matches || matches.length !== 3) {
        return { state: false, error: 'Invalid base64 image string' }
    }

    const mimeType = matches[1];
    
    const base64Data = matches[2];
    
    const buffer = Buffer.from(base64Data, 'base64');

    
    const extension = mimeType.split('/')[1].split(';')[0];
    const fileName = `photo_${Date.now()}${Math.random().toString().slice(2)}.${extension}`
    const filePath = path.join(PHOTO_DIR, fileName);
    try {
        fs.writeFileSync(filePath, buffer);
        return { state: true, fileName: `${API_HOST}/data/photo/${fileName}` }
    } catch (error) {
        return { state: false, error }
    }
}


app.get('/add-photo', (req, res) => {
    res.redirect('/');
});


app.get('/albums', (req, res) => {
    
    const albums = readAlbums();
    
    
    res.json({data: albums, server: true });
});


app.post('/albums', (req, res) => {
    const albums = readAlbums();
    const { city, location, note, photo } = req.body;
    if (!photo || !photo.startsWith('data:image/')) {
        res.status(400).json({ error: 'Invalid image format' });
        return;
    }
    const savePhotoReuslt = savePhoto(photo);
    if (!savePhotoReuslt.state) {
        res.status(500).json({ error: savePhotoReuslt.error });
        return;
    }

    const newPhoto = {
        id: Date.now(),
        city,
        location,
        note,
        createDate: Date.now(),
        photo: savePhotoReuslt.fileName
    };
    const newAlbums = [newPhoto, ...albums]
    writeAlbums(newAlbums);
    res.status(201).json({ data: newPhoto, server: true });
});


app.delete('/albums/:id', (req, res) => {
    const albums = readAlbums();
    const albumIndex = albums.findIndex(album => album.id === parseInt(req.params.id, 10));

    if (albumIndex !== -1) {
        const currentAlbum = albums[albumIndex];
        const imageUrl = currentAlbum.photo;
        if (imageUrl.startsWith(API_HOST)) {
            const filePath = path.join(__dirname, imageUrl.substring(API_HOST.length));
            fs.unlink(filePath, (err) => {
                if (err) {
                    console.error(`Error deleting file: ${err}`);
                    return;
                }
            });
        }
        albums.splice(albumIndex, 1);
        writeAlbums(albums);
        res.status(200).json({data: currentAlbum, server: true });
    } else {
        res.status(404).send('Album not found');
    }
});


app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
    console.log(API_HOST);
});
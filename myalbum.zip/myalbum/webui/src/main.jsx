import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import App from './pages/App'
import AddPhoto from './pages/AddPhoto';

import './index.css'
import './tool.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<App />}/>
        <Route path="/add-photo" element={<AddPhoto />}/>
      </Routes>
    </BrowserRouter>
  </React.StrictMode>,
)

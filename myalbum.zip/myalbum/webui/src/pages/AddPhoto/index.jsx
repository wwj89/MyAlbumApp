import { useState } from "react";
import { useNavigate } from 'react-router-dom';
import { API_HOST, fetchWithCache } from '../../config';
import Layout from "../../components/Layout";
import PhotoTaker from "../../components/PhotoTaker";

import './index.css';

const defaultFromData = {
    location: '',
    city: '',
    note: '',
    photo: '',
}

const AddPhoto = (props) => {
    const [formValues, setFormValues] = useState(defaultFromData);
    const navigate = useNavigate();

    const getLocation = (event) => {
        if (confirm("Do you want to use your current location?")) {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(showPosition, showError);
            } else {
                alert("Geolocation is not supported by this browser.");
            }
        } else {
            alert("You chose not to use your current location.You can manually enter location information.");
        }

        function showPosition(position) {
            const latitude = position.coords.latitude;
            const longitude = position.coords.longitude;

            // 根据经纬度值确定方向  
            const latDirection = latitude >= 0 ? 'N' : 'S';
            const lonDirection = longitude >= 0 ? 'E' : 'W';

            // 转换为"东经/西经X度，北纬/南纬X度"格式  
            const formattedPosition = `${lonDirection} ${Math.abs(longitude).toFixed(2)}°, ${latDirection} ${Math.abs(latitude).toFixed(2)}°`;

            setFormValues({ ...formValues, location: formattedPosition });
        }

        function showError(error) {
            switch (error.code) {
                case error.PERMISSION_DENIED:
                    console.log("User denied the request for Geolocation.");
                    break;
                case error.POSITION_UNAVAILABLE:
                    console.log("Location information is unavailable.");
                    break;
                case error.TIMEOUT:
                    console.log("The request to get user location timed out.");
                    break;
                case error.UNKNOWN_ERROR:
                    console.log("An unknown error occurred.");
                    break;
            }
        }
    }

    const onPhotoChange = (imageBase64String) => {
        setFormValues({ ...formValues, photo: imageBase64String });
    }

    const onInputLocation = (event) => {
        setFormValues({ ...formValues, location: event.target.value });
    }

    const handleSubmit = (event) => {
        // 取消表单默认行为，使用fetch调用接口传递数据
        event.preventDefault();
        // 获取表单数据
        const formData = Array.from(event.target.querySelectorAll("[name]")).map(o => ({ [o.name]: o.value })).reduce((p, c) => ({ ...p, ...c }));
        
        const id = Date.now();
        const extraFields = { id, createDate: id }

        // 在这里处理照片上传逻辑
        const data = { ...extraFields, ...formValues, ...formData };

        if (!data.photo) {
            return alert("please take a photo.");
        }

        // 调用接口保存数据
        fetchWithCache(`${API_HOST}/albums`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: data
        }).then(response => response.json()).then((res) => {
            const { _, server } = res;
            if (!server) {
                const albums = JSON.parse(localStorage.getItem('albums') || '[]');
                try {
                    localStorage.setItem('albums', JSON.stringify([data, ...albums]));
                } catch (error) {
                    alert('The app local storage is full, and the data will not be saved.')
                }
            }
            setFormValues(defaultFromData);
            navigate('/');
        }).catch(error => console.error(error));
    }

    return (
        <Layout title="Add Travel Photo">
            <div className="add-form">
                <form onSubmit={handleSubmit}>
                    <label htmlFor="location">
                        <div>
                            Location
                        </div>
                        <div className="control-box">
                            <input className="control" type="text" id="location" name="location" value={formValues.location} onChange={onInputLocation} />
                            <button className="gps-fixed" onClick={getLocation} title="get your location" type="button">
                                <svg t="1710500252203" className="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2406" width="128" height="128">
                                    <path d="M512 341.333333c-94.293333 0-170.666667 76.373333-170.666667 170.666667s76.373333 170.666667 170.666667 170.666667 170.666667-76.373333 170.666667-170.666667-76.373333-170.666667-170.666667-170.666667z m381.44 128C873.813333 291.413333 732.586667 150.186667 554.666667 130.56V42.666667h-85.333334v87.893333C291.413333 150.186667 150.186667 291.413333 130.56 469.333333H42.666667v85.333334h87.893333c19.626667 177.92 160.853333 319.146667 338.773333 338.773333V981.333333h85.333334v-87.893333c177.92-19.626667 319.146667-160.853333 338.773333-338.773333H981.333333v-85.333334h-87.893333zM512 810.666667c-164.906667 0-298.666667-133.76-298.666667-298.666667s133.76-298.666667 298.666667-298.666667 298.666667 133.76 298.666667 298.666667-133.76 298.666667-298.666667 298.666667z" p-id="2407"></path>
                                </svg>
                            </button>
                        </div>
                    </label>
                    <label htmlFor="city">
                        <div>
                            City
                        </div>
                        <input className="control" type="text" name="city" id="city" />
                    </label>
                    <label htmlFor="note">
                        <div>
                            Note
                        </div>
                        <textarea name="note" id="note" cols="30" rows="10"></textarea>
                    </label>
                    <div className="mb-8">
                        <div>Photo</div>
                        <PhotoTaker onChange={onPhotoChange} />
                    </div>
                    <div className="center">
                        <button type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </Layout>
    )

}

export default AddPhoto;

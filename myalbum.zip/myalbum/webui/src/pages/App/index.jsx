import { useState, useEffect } from 'react'
import { API_HOST, fetchWithCache } from '../../config';
import Layout from "../../components/Layout";
import Card from '../../components/Card'

import './index.css'
import { Link } from 'react-router-dom';

function App() {
  const [list, setList] = useState([]);

  const fetchData = () => {
    fetchWithCache(`${API_HOST}/albums`)
      .then(response => response.json())
      .then(result => {
        const { data, server } = result;
        if (data && data.length > 0) {
          setList(data)
          if (server) {
            localStorage.setItem('albums', JSON.stringify(data))
          }
        }
      })
      .catch(err => console.log(err))
  }

  const onDelete = (id) => {
    setList(list.filter(item => item.id !== id));
  }


  useEffect(() => {
    fetchData();
  }, []);

  return (
    <Layout title="My Travel Album">
      <div className="card-box">
        {
          list && list.length > 0 ? list.map((item) => (<Card key={item.id} data={item} onDelete={onDelete} />)) : (
            <div>
              <span>Nothing here.</span>
              <br />
              <span>You can click on </span>
              <Link to={"/add-photo"}>Take Photo</Link>
            </div>
          )
        }
      </div>
    </Layout>
  )
}

export default App;

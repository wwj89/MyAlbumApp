const API_HOST = 'http://localhost:3000';
const syncOfflineRequests = async () => {
        const storedRequests = JSON.parse(localStorage.getItem('offlineRequests')) || [];
    let newStoredRequests = JSON.parse(localStorage.getItem('offlineRequests')) || [];
    for (let index = 0; index < storedRequests.length; index++) {
        const requestData = storedRequests[index];
        try {
            const result = await fetch(requestData.url, requestData.options).then(response => response.json());
            newStoredRequests = newStoredRequests.filter(req => req.timestamp !== requestData.timestamp);
        } catch (error) {
            console.error('Sync Faild:', error);
        }
    }
    
    localStorage.setItem('offlineRequests', JSON.stringify(newStoredRequests));
}

window.addEventListener('online', syncOfflineRequests);

document.addEventListener('DOMContentLoaded', () => {
        const storedRequests = JSON.parse(localStorage.getItem('offlineRequests')) || [];
    if (storedRequests.length > 0 && navigator.onLine) {
                syncOfflineRequests()
    }
});

function createResponse(data) {
    return Promise.resolve(new Response(JSON.stringify(data), {
        status: 200,         statusText: 'OK',         headers: new Headers({
            'Content-Type': 'application/json',                     })
    }))
}

function saveOfflineRequest(url, options) {
    const storedRequests = JSON.parse(localStorage.getItem('offlineRequests')) || [];
    const requestData = { url, options, timestamp: Date.now() };
    if (typeof options.body != 'string') {
        requestData.options.body = JSON.stringify(options.body);
    }
    storedRequests.push(requestData);
    localStorage.setItem('offlineRequests', JSON.stringify(storedRequests));
    alert('The app is currently offline,\n and the data will be automatically synchronized once the network is restored.')
}

function returnLocalMode(url, options) {
    const urlObj = new URL(url);
    if (urlObj.pathname.includes('/album') && options.method === 'GET') {
        return createResponse({
            data: JSON.parse(localStorage.getItem('albums') || '[]'),
            server: false
        })
    }
    if (urlObj.pathname.includes('/album') && options.method === 'POST') {
        saveOfflineRequest(url, options);
        return createResponse({ data: true, server: false });
    }
    if (urlObj.pathname.includes('/album') && options.method === 'DELETE') {
        const deleteId = urlObj.pathname.split('/').slice(-1)[0];
                        const offlineRequests = JSON.parse(localStorage.getItem('offlineRequests') || '[]');
                const filterCallback = (request, index) => {
            const condition1 = request.options.method === 'POST';
            const condition2 = JSON.parse(request.options.body || "{}").id == deleteId;
            return condition1 && condition2;
        }
                const addRequest = offlineRequests.find(filterCallback);
        if (addRequest) {
                        offlineRequests.filter(request => request.timestamp !== addRequest.timestamp);
            localStorage.setItem('offlineRequests', JSON.stringify(offlineRequests));
        } else {
                                    saveOfflineRequest(url, options);
        }
        return createResponse({ data: true, server: false });
    }
}

function fetchWithCache(url, options = { method: 'GET' }) {
    if (navigator.onLine) {
        const newBody = options.body ? { body: JSON.stringify(options.body) } : {};
        return fetch(url, { ...options, ...newBody }).catch(error => {
            console.log(error);
            return returnLocalMode(url, options);
        });
    } else {
        return returnLocalMode(url, options);
    }
}

export {
    API_HOST,
    fetchWithCache
}
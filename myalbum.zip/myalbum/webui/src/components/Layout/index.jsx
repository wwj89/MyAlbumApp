import Footer from "../Footer";
import Header from "../Header";

import "./index.css";

const Layout = (props) => {
    const { children, title } = props;
    return (
        <div className="container">
            <Header text={title}/>
            <div className="main">
                {children}
            </div>
            <Footer />
        </div>
    )
}

export default Layout;

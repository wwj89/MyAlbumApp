import { useEffect, useRef } from "react"
import Header from "../../Header";

import './index.css'
import { Link } from "react-router-dom";
import { useState } from "react";


const Taker = (props) => {
    const { setIsCameraOpen, onHide, onChange } = props;

    const videoRef = useRef(null);
    let stream;


    const unloadVideoStream = () => {
        if (videoRef.current) {
            videoRef.current.pause();
            videoRef.current.srcObject = null;
        }
        if (stream) {
            stream.getTracks().forEach(track => {
                track.stop();
            });
            stream = null;
        }
    }


    const loadVideoStream = () => {
        if (videoRef.current) {
            if (navigator.mediaDevices.getUserMedia) {
                navigator.mediaDevices.getUserMedia({ video: true })
                    .then((streamReceived) => {
                        stream = streamReceived;
                        videoRef.current.srcObject = stream;
                    })
                    .catch(function (error) {
                        console.log("Something went wrong!", error);
                    });
            } else {
                console.log("getUserMedia not supported in this browser!");
            }
        }
    }


    const onTakeSnapshot = e => {
        const video = videoRef.current;
        if (video.readyState >= 3) {
            const imageString = takeSnapshot();
            if (onChange) {
                onChange(imageString);
                unloadVideoStream();
                onHide();
            }
        } else {

            video.addEventListener('loadeddata', takeSnapshot, { once: true });
        }
    }


    function takeSnapshot() {
        const video = videoRef.current;

        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);


        const result = canvas.toDataURL('image/png');
        return result
    }

    const onClose = () => {
        unloadVideoStream();
        onHide();
    }

    useEffect(() => {
        if (setIsCameraOpen) {
            loadVideoStream();
        }
    }, [setIsCameraOpen]);


    return (
        <div className={`layer ${setIsCameraOpen ? '' : 'hidden'}`}>
            <div className="take-photo-container">
                <Header text='Take Travel Photo' />
                <video muted autoPlay className="video mb-8" ref={videoRef}></video>
                <div className="center">
                    <button onClick={onTakeSnapshot} type="button">Take Photo</button>
                    <button className="ml-8" onClick={onClose} type="button">
                        Close
                    </button>
                </div>
            </div>
        </div>
    )
}


export default Taker;

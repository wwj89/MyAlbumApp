import { useState } from "react";
import { Link } from "react-router-dom";

import './index.css'
import Taker from "./Taker";
import { useEffect } from "react";

const PHOTO_TYPE = {
    "SELECT": "SELECT",
    "TAKE": "TAKE"
}

const transparentImage = "data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQImWNgYGBgAAAABQABh6FO1AAAAABJRU5ErkJggg==";

const PhotoTaker = (props) => {
    const { onChange } = props;
    const [photo, setPhoto] = useState('');
    const [photoType, setPhotoType] = useState(PHOTO_TYPE.SELECT);

    const [takerOpen, setTakerOpen] = useState(false);

    const handleSelectChange = (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = function () {
                var base64String = reader.result;
                setPhoto(base64String);
                setPhotoType(PHOTO_TYPE.SELECT);
            }
            reader.readAsDataURL(file);
        }
    }

    const handleTakePhoto = (base64String) => {
        setPhoto(base64String);
        setPhotoType(PHOTO_TYPE.TAKE);
    }

    const onTakePhoto = () => {
        setTakerOpen(true);
    }

    const hideTaker = () => {
        setTakerOpen(false);
    }

    useEffect(()=>{
        if(onChange && photo) {
            onChange(photo, photoType);
        }
    },[photo])

    return (
        <>
            <div className="photo-type">
                <label htmlFor="file" className="select-photo">
                    {
                        photo && photoType == PHOTO_TYPE.SELECT ?
                            (<img src={photo} alt="preview image" className="img-fit" />)
                            :
                            (<div>
                                Select a photo,
                                <br />
                                please touch here.
                            </div>)
                    }
                    <input className="hidden" type="file" id="file" onChange={handleSelectChange}
                        accept="image/*"
                    />
                </label>
                <div className="take-photo" onClick={onTakePhoto}>
                    {
                        photo && photoType == PHOTO_TYPE.TAKE ?
                            (<img src={photo} alt="preview image" className="img-fit" />)
                            :
                            (<div>
                                To take a photo,
                                <br />
                                please touch here.
                            </div>)
                    }
                </div>
            </div>
            <input type="hidden" value={photo} name="photo" />
            <Taker setIsCameraOpen={takerOpen} onHide={hideTaker} onChange={handleTakePhoto} />
        </>
    )
}

export default PhotoTaker;

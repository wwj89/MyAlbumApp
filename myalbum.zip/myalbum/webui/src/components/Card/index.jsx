import { API_HOST, fetchWithCache } from '../../config';
import './index.css';


const defaultData = {
    id: -1,
    city: 'Tokyo',
    location: 'E 35.6895, N 139.6917',
    photo: '',
    note: 'Tokyo is the capital of Japan.',
}

const Card = (props) => {
    const { data = defaultData, onDelete } = props;

    const handleDelete = () => {
        
        if (confirm('Are you sure you want to delete this photo?')) {
            const { id } = data;
            
            fetchWithCache(`${API_HOST}/albums/${id}`, { method: 'DELETE' }).then(response => response.json()).then((res) => {
                const { data, server } = res;
                if(!server) {
                    const albums = JSON.parse(localStorage.getItem('albums') || '[]').filter(album => album.id !== id);
                    localStorage.setItem('albums', JSON.stringify(albums));
                }
                
                onDelete(id);
            }).catch((err) => {
                
                console.error(err);
            })
        }
    }

    return (
        <div className='card'>
            <img src={data.photo} alt="pic" />
            <div className='info'>
                <div>City: {data.city}</div>
                <div>Location: {data.location}</div>
                <div>
                    Note: {data.note}
                </div>
                <div className="operation">
                    <button className='detail' style={{ visibility: 'hidden' }}>Detail</button>
                    <button className='delete danger' onClick={handleDelete}>Remove</button>
                </div>
            </div>
        </div>
    )
}

export default Card;

import fs from 'fs'
import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import { createHtmlPlugin } from 'vite-plugin-html'
import copy from 'rollup-plugin-copy'
import generateServiceWorker from './buildScript/generateSW'

import path from 'path';

export default defineConfig(({ command, mode }) => {
  const prodPlugins = [
    generateServiceWorker(),
    copy({
      targets: [
        { src: ['public/service-worker.js'], dest: '../public/' },
      ]
    })
  ];
  const extraPlugins = (mode === 'production' && prodPlugins.length > 0) ? prodPlugins : [];
  return {
    plugins: [
      react(),
      createHtmlPlugin({
        minify: false,
        entry: 'src/main.jsx',
        template: 'index.html',
        inject: {
          data: {
            title: 'index',
            manifest: `<link rel="manifest" href="/manifest.json">`,
            injectScript: fs.readFileSync(path.resolve(__dirname, 'buildScript/register.html')).toString(),
          }
        },
      }),
       ...extraPlugins, 
    ],
    build: {
      outDir: '../public',
      rollupOptions: {
        output: {
          entryFileNames: 'js/[name]-[hash].js',
          chunkFileNames: 'js/[name]-[hash].js',
          assetFileNames(assetInfo) {
            if (assetInfo.name.endsWith(".css")) {
              return "css/[name]-[hash].css";
            }
            const imageExt = ['.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp', '.ico', '.bmp'];
            if (imageExt.some(ext => assetInfo.name.endsWith(ext))) {
              return "img/[name]-[hash].[ext]";
            }
            return "assets/[name]-[hash].[ext]";
          },
          manualChunks: {
            "react": ["react"],
            "react-dom": ["react-dom"],
            "react-router-dom": ["react-router-dom"],
          }
        }
      }
    },
    server: {
      port: 3032,
    },
    preview: {
      port: 8080,
    },
  }
})

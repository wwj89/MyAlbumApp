import fs from 'fs'
import path from 'path';

function generateServiceWorker() {
    return {
        name: 'generate-manifest',
        buildStart() {
            const destPath = path.resolve(process.cwd(), 'public/service-worker.js');
            if(fs.existsSync(destPath)){
                fs.unlinkSync(destPath);
                console.log('delete public/service-worker.js --------');
            }
        },
        generateBundle(_, bundle) {
            const destPath = path.resolve(process.cwd(), 'public/service-worker.js');
            const swTemplate = fs.readFileSync(path.resolve(process.cwd(), 'buildScript/sw-template.js'), 'utf-8');
            const pathString = Object.entries(bundle).map(([, value]) => `"/${value.fileName}"`).join(',\n');
            const swjsContent = swTemplate.replace(`/*<- CACHE_FILE_1 ->*/`, pathString);
            fs.writeFileSync(destPath, swjsContent);
            console.log('\nrebuild public/service-worker.js -------- ');
        },
    };
}

export default generateServiceWorker;

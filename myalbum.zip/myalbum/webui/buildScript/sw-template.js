const CACHE_NAME = 'ALBUM_CACHE';
const NETWORK_STATE = {
    ONLINE: 'ONLINE',
    OFFLINE: 'OFFLINE'
}
const networkState = {
    state: NETWORK_STATE.ONLINE
}

const CACHE_FILE_1 = [
    /*<- CACHE_FILE_1 ->*/
];
const CACHE_FILE_2 = [
    '/',
    '/index.html',
    '/logo.svg',
    '/manifest.json',
    "/icon/favicon-16x16.png",
    "/icon/favicon-32x32.png",
    "/icon/favicon-48x48.png",
    "/icon/apple-touch-icon-57x57.png",
    "/icon/apple-touch-icon-60x60.png",
    "/icon/apple-touch-icon-72x72.png",
    "/icon/apple-touch-icon-76x76.png",
    "/icon/apple-touch-icon-114x114.png",
    "/icon/apple-touch-icon-120x120.png",
    "/icon/apple-touch-icon-144x144.png",
    "/icon/apple-touch-icon-152x152.png",
    "/icon/apple-touch-icon-180x180.png",
    "/icon/favicon-192x192.png",
    "/icon/favicon-256x256.png",
    "/icon/favicon-384x384.png",
    "/icon/favicon-512x512.png",
]
self.addEventListener('install', (event) => {
    self.skipWaiting();
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            return cache.addAll([...CACHE_FILE_1, ...CACHE_FILE_2]);
        })
    );
});
self.addEventListener("activate", (event) => {
    event.waitUntil(clients.claim());
});

self.addEventListener('fetch', (event) => {
    event.respondWith(fetchNetworkFirst(event));
});


function fetchNetworkFirst(event) {
    const request = event.request;
    return fetch(request).then(response => {
        
        const tempResponse = response.clone();
        
        caches.open(CACHE_NAME).then(cache => {
            if (request.method === 'GET') {
                cache.put(request, tempResponse);
            }
        });
        return response;
    }).catch(() => {
        
        return caches.match(request);
    });
}
